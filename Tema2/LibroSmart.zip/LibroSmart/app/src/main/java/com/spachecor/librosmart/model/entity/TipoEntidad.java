package com.spachecor.librosmart.model.entity;

public enum TipoEntidad {
    LIBRO,
    LISTA
}
